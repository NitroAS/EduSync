const number = [10 , 14 , 20 , 9 , 16 , 22 ]
console.log(number);

let number2 = [10 , 14 , 20 , 9 , 16 , 22 ]
let resultadoArray2 = number2.filter (acima => (acima) >= 15);
console.log(resultadoArray2);