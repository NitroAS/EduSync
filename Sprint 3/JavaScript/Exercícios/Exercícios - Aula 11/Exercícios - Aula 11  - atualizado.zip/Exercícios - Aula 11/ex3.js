const array = [3,4,8,9,15]

let totalAoCubo = array.map  (cubo => cubo**3)

console.log(`Base: ${array}`);
console.log(`Resultado ao cubo: ${totalAoCubo}`);