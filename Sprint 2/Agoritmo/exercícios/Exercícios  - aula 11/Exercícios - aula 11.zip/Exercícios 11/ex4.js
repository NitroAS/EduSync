var Base = 28
var Altura = 12
var Divisao = 2
var operacao = prompt ('Digite Base para obter o Resultado');
console.log(operacao);

switch(operacao)
{
    case 'base':
    console.log( (Base + Altura) / Divisao);
    break;
}