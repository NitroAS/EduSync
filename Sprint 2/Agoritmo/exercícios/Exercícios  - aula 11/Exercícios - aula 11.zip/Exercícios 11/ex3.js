var segundos = 3600;
console.log(segundos)

var minutos = segundos / 60;
console.log(minutos)

var horas = minutos / 60;
console.log(horas)
