var A =  20
var B =  15
var C =  12
var X = (A + B)**2 + C;
console.log(X);