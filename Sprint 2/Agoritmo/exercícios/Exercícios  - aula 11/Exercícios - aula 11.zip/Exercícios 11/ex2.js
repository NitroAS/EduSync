var nota = (10 + 10 + 10) / 3;
    
if (nota >= 5)
{
    console.log('Aprovado!');
    if(nota >= 10){
        console.log("Atingiu média final máxima!")
    }
}
else
{
    console.log('Reprovado');
}