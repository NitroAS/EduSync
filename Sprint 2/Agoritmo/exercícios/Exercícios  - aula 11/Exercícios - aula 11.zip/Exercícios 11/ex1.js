var A =  250
var B =  750
var C =  2
var X = (A + B) / C;
console.log(X);