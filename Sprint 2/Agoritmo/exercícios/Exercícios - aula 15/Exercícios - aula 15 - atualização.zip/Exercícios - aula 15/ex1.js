 var vetor = []

 for (var index = 0; index < 8; index++) {
      vetor[index] = index**3
      console.log(vetor[index])
     
 }