
var nomes = ['Julia' , 'Roberta' , 'Carol' ,'Marcela', 'Ingrid' ];

var nome =  prompt ('digite seu nome')



if (nomes != nome) {
  console.log('Achei');
}

else 
{
  console.log('Não Achei');
}





